module.exports={
   getTitle: 'article > h2',
   getAge : 'article > :nth-child(3)'
}
