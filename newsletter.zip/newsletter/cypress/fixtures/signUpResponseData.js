module.exports = {
    analyticString1: "",
    analyticString2: "",
    email:"test@gmail.com",
    majorSource: "WNL",
    minorSource: "INLINE",
    preferences: [{preferenceId: '579C4F1D-8F2C-4898-9F2E-044CF1071AA9', optinValue: 'H'}],
    sendToEsp: true
}
