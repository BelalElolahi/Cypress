module.exports={
    changedText :'h4',
    errorMessageElement:'p[role="alert"]',
    shadowRoot:'journey-inline-newsletter',
    submitButton:'button[id="submit-button"]',
    textContainer:'.main-section',
    textInput :'input[id="emailInput"]',
}
