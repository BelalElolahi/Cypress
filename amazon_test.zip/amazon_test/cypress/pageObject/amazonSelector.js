module.exports ={
    searchInput : '#twotabsearchtextbox',
    firsItemSelected :"div[data-asin][data-index='1']",
    firsItemSelectedLink:"div[data-asin][data-index='1'] > div > div > div > div >div > div > div > span",
    addToCartButton:'#add-to-cart-button',
    cartButton:'.nav-cart-icon',
    firstItemCart :"div[data-asin]:first" ,
    lastItemCart:"div[data-asin]:last",
    secondItemSelected:"div[data-asin][data-index='2']",
    secondItemSelectedLink:"div[data-asin][data-index='2'] > div > div > div > div >div > div > div > span",
    cartItemCount:'[data-item-count]',
}