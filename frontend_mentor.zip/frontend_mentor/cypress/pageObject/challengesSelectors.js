module.exports={
    AllChallengesCards :'.Card__Wrapper-sc-1jwkgbk-0 > .image-wrapper ',
    challengeCards:'.Card__Wrapper-sc-1jwkgbk-0',
    filterButton:'.DropdownFilter__Button-sc-c47e06-1',
    freeCards:'.Flags__Wrapper-sc-9n2rm2-0 > span',
    hiddenText:'.Question__Answer-sc-qkfu30-2 > .Spacer__Wrapper-sc-1qmp1cv-0 > .jUCbqL',
    plusIcon:'.Question__Summary-sc-qkfu30-1:first > .fa-plus > path',
    selectedChallenge:'.Card__Wrapper-sc-1jwkgbk-0:first > div > a',
    typeFreeCheckBox:'[id="types-free"]',
}
