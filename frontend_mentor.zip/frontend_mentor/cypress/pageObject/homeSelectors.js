module.exports={
    NavElement:'#menu > :nth-child(1) > a ',
    viewAllChallengesButton :'.LatestChallenges__Footer-sc-15s1dlf-2 > .UnderlinedLink__StyledLink-sc-fs2h13-0'
}
