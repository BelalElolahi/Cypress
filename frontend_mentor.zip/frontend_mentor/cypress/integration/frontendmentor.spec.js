/// <reference types="cypress" />
import homeSelector from '../pageObject/homeSelectors';
import challengesPageSelectors from '../pageObject/challengesSelectors';

const data = ['/challenges', '/solutions', '/resources', '/pro', '/hiring']

describe('Frontend Mentor Test', () => {
  beforeEach(() => {
    cy.visit('https://www.frontendmentor.io/')
  })

  it('verify nav bar elements have  the correct element', () => {
    data.map((element, indx) => {
      cy.getNaveHrefValue(indx + 1).then(value => {
        expect(element).eq(value)
      })
    });
  })

  it('verify all challenges appear ', () => {
    cy.get(challengesPageSelectors.challengeCards).should('exist')
    cy.get(challengesPageSelectors.challengeCards).then(homeItems => {
      cy.get(homeSelector.viewAllChallengesButton).click()
      cy.get(challengesPageSelectors.challengeCards).find('li').then(challengesItems => {
        expect(challengesItems.length).to.be.greaterThan(homeItems.length)
      })
    })
  })

  it('verify all the appearing challenges are free only', () => {
    cy.get(homeSelector.NavElement).click()    
    cy.get(challengesPageSelectors.filterButton).click()
    cy.get(challengesPageSelectors.typeFreeCheckBox).check({ force: true })
    cy.get(challengesPageSelectors.freeCards).each((el,indx)=>{
      expect(el.text()).to.be.eq('Free')
    })
  })

  it('verify you redirect to the selected challenge page', () => {
    cy.get(homeSelector.NavElement).click()
    cy.get(challengesPageSelectors.selectedChallenge)
      .invoke('attr', 'href')
      .then((data) => {
        cy.get(challengesPageSelectors.selectedChallenge).click()
        cy.url().should('include', data)
      })
  })

  it('verify the hidden text is appear', () => {
    cy.get(challengesPageSelectors.selectedChallenge).click()
    cy.get(challengesPageSelectors.plusIcon).click()
    cy.get(challengesPageSelectors.hiddenText).should('exist')

  });
});
